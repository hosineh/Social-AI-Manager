package com.example.socialaimanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class SocialAccount(val platform: String, val username: String, val connected: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SocialManagerApp() }
    }
}

@Composable
fun SocialManagerApp() {
    var selectedTab by remember { mutableStateOf("الحسابات") }
    var showAddDialog by remember { mutableStateOf(false) }
    var platform by remember { mutableStateOf("Facebook") }
    var username by remember { mutableStateOf("") }
    var accounts by remember {
        mutableStateOf(
            listOf(
                SocialAccount("Facebook", "facebook_account_1", false),
                SocialAccount("Instagram", "instagram_account_1", false),
                SocialAccount("TikTok", "tiktok_account_1", false),
                SocialAccount("Snapchat", "snapchat_account_1", false)
            )
        )
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF3157D5),
            secondary = androidx.compose.ui.graphics.Color(0xFF52627A),
            background = androidx.compose.ui.graphics.Color(0xFFF5F7FB)
        )
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                Surface(color = MaterialTheme.colorScheme.primary) {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        Text("Social AI Manager", color = androidx.compose.ui.graphics.Color.White,
                            fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("إدارة حسابات التواصل من مكان واحد", color = androidx.compose.ui.graphics.Color.White)
                    }
                }
            },
            bottomBar = {
                NavigationBar {
                    listOf("الحسابات", "التعليقات", "النشاط").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = {},
                            label = { Text(tab) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                when (selectedTab) {
                    "الحسابات" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("حساباتك", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text("${accounts.size} حسابات مضافة • الهدف 20+",
                                    color = MaterialTheme.colorScheme.secondary)
                            }
                            Button(onClick = { showAddDialog = true }) { Text("إضافة حساب") }
                        }
                        Spacer(Modifier.height(12.dp))
                        Card(shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.padding(14.dp)) {
                                Text("حالة الربط", fontWeight = FontWeight.Bold)
                                Text("هذه نسخة تجريبية للواجهة. لم يتم ربط أي منصة بعد.")
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(accounts) { account ->
                                Card(shape = RoundedCornerShape(14.dp)) {
                                    Row(Modifier.fillMaxWidth().padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(account.platform, fontWeight = FontWeight.Bold)
                                            Text(account.username, color = MaterialTheme.colorScheme.secondary)
                                        }
                                        Text(if (account.connected) "متصل" else "غير مربوط",
                                            color = MaterialTheme.colorScheme.secondary)
                                    }
                                }
                            }
                        }
                    }
                    "التعليقات" -> {
                        Text("مساعد التعليقات", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("اكتب وصف المنشور لتحصل على اقتراح تعليق، ثم راجعه وانشره بنفسك عبر أدوات المنصة الرسمية.")
                        var post by remember { mutableStateOf("") }
                        var suggestion by remember { mutableStateOf("") }
                        OutlinedTextField(
                            value = post, onValueChange = { post = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("وصف المنشور") },
                            minLines = 3
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = {
                            suggestion = if (post.isBlank()) "" else
                                "منشور جميل! شكراً على المشاركة، أعجبني المحتوى."
                        }, enabled = post.isNotBlank()) { Text("اقتراح تعليق") }
                        if (suggestion.isNotBlank()) {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp)) {
                                    Text("اقتراح للمراجعة", fontWeight = FontWeight.Bold)
                                    Text(suggestion)
                                }
                            }
                        }
                    }
                    else -> {
                        Text("سجل النشاط", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("لا يوجد نشاط بعد. ستظهر هنا عمليات الربط والمراجعة عند إضافة الخادم.")
                    }
                }
            }
        }

        if (showAddDialog) {
            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                title = { Text("إضافة حساب") },
                text = {
                    Column {
                        Text("اختر المنصة")
                        Spacer(Modifier.height(6.dp))
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick = { expanded = true }) { Text(platform) }
                            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                listOf("Facebook", "Instagram", "TikTok", "Snapchat").forEach {
                                    DropdownMenuItem(text = { Text(it) }, onClick = {
                                        platform = it; expanded = false
                                    })
                                }
                            }
                        }
                        OutlinedTextField(value = username, onValueChange = { username = it },
                            label = { Text("اسم الحساب / وصفه") })
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (username.isNotBlank()) {
                            accounts = accounts + SocialAccount(platform, username.trim(), false)
                            username = ""
                            showAddDialog = false
                        }
                    }) { Text("إضافة") }
                },
                dismissButton = {
                    TextButton(onClick = { showAddDialog = false }) { Text("إلغاء") }
                }
            )
        }
    }
}

from datetime import datetime, timezone
import os
import sqlite3
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

DB_PATH = os.getenv("DB_PATH", "social_ai_manager.db")
app = FastAPI(title="Social AI Manager API", version="0.1.0")
PLATFORMS = {"facebook", "instagram", "tiktok", "snapchat"}

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            platform TEXT NOT NULL, label TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending_oauth',
            created_at TEXT NOT NULL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS activity (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account_id INTEGER, action TEXT NOT NULL,
            details TEXT NOT NULL, created_at TEXT NOT NULL)""")

init_db()

class AccountIn(BaseModel):
    platform: str
    label: str = Field(min_length=1, max_length=100)

class CommentDraftIn(BaseModel):
    platform: str
    post_context: str = Field(min_length=1, max_length=3000)
    tone: str = Field(default="friendly", max_length=40)

@app.get("/health")
def health():
    return {"ok": True, "service": "Social AI Manager API"}

@app.get("/accounts")
def list_accounts():
    with db() as c:
        rows = c.execute("SELECT * FROM accounts ORDER BY id DESC").fetchall()
    return [dict(r) for r in rows]

@app.post("/accounts")
def add_account(payload: AccountIn):
    platform = payload.platform.strip().lower()
    if platform not in PLATFORMS:
        raise HTTPException(400, "Unsupported platform")
    with db() as c:
        count = c.execute("SELECT COUNT(*) FROM accounts").fetchone()[0]
        if count >= 100:
            raise HTTPException(400, "Starter limit is 100 account records")
        cur = c.execute(
            "INSERT INTO accounts(platform,label,status,created_at) VALUES(?,?,?,?)",
            (platform, payload.label.strip(), "pending_oauth",
             datetime.now(timezone.utc).isoformat()))
        account_id = cur.lastrowid
    return {"id": account_id, "platform": platform, "label": payload.label,
            "status": "pending_oauth",
            "note": "Placeholder only; this is not a connected social account."}

@app.post("/comments/draft")
def draft_comment(payload: CommentDraftIn):
    if not payload.post_context.strip():
        raise HTTPException(400, "Post context is required")
    return {
        "draft": "شكراً على المشاركة! محتوى جميل ومفيد، بالتوفيق دائماً.",
        "requires_human_review": True,
        "note": "Demo template only. Connect an approved AI provider for contextual drafts."
    }

@app.get("/capabilities")
def capabilities():
    return {
        "account_records": "supported in starter",
        "oauth": "requires developer app registration and platform approval",
        "post_reading": "only with granted official scopes",
        "comment_drafting": "demo only; AI provider not connected",
        "likes_or_bulk_comments": "not implemented; do not automate where platform APIs or policies do not permit it",
        "snapchat": "Snap Kit Login Kit is identity/login, not general Snapchat engagement automation"
    }
